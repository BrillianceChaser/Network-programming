#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>
#include <pthread.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/epoll.h>
#include <fcntl.h>
#include <errno.h>
// 宏定义
#define PORT 8080
#define MAX_CLIENTS 5
#define MAX_EVENTS 1024
#define MAX_SIZE 256
#define MAGIC 0xDA12EEEE
#define puterror(msg) \
	{                 \
		perror(msg);  \
		exit(1);      \
	}

#define PRINT_LOG(format, str...)                                                   \
	{                                                                               \
		printf("[%s,%s,%d] " format "\n", __FUNCTION__, __FILE__, __LINE__, ##str); \
	}

#define print_fd_set(fdset)                                               \
	{                                                                     \
		printf("[%s,%s,%d] redset:\n", __FUNCTION__, __FILE__, __LINE__); \
		for (int fd = 0; fd < FD_SETSIZE; ++fd)                           \
		{                                                                 \
			if (FD_ISSET(fd, &fdset))                                     \
			{                                                             \
				printf("%d\n", fd);                                       \
			}                                                             \
		}                                                                 \
	}
// 定义数据传输的结构体
struct clientMessage
{
	int magic;			// 魔数
	int type;			// 类型1   // 消息类型
	char msg[MAX_SIZE]; // 消息内容
};

struct serverMessage
{
	int magic;
	int type;		// 类型2
	long timestamp; // 时间戳
};

pthread_mutex_t mutex; // 互斥锁
struct sockaddr_in serverAddress, clientAddress;

int main(int argc, char *argv[])
{
	// 创建套接字
	int socketfd = socket(AF_INET, SOCK_STREAM, 0);
	// 判断错误
	if (socketfd == -1)
		puterror("socket");
	// 打印日志
	PRINT_LOG("Value of socketfd: %d", socketfd);
	// 设置服务器地址信息
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = INADDR_ANY;
	serverAddress.sin_port = htons(PORT);
	// 绑定 Server 地址到 Socket
	if (bind(socketfd, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) == -1)
		puterror("bind");
	// 开启监听
	if (listen(socketfd, MAX_CLIENTS) == -1)
		puterror("listen");
	// 创建epoll实例
	int epfd = epoll_create(1);
	if (epfd == -1)
		puterror("epoll_create");
	struct epoll_event ev;
	ev.data.fd = socketfd;
	ev.events = EPOLLIN | EPOLLET; // 设置边沿触发模式
	epoll_ctl(epfd, EPOLL_CTL_ADD, socketfd, &ev);
	struct epoll_event evs[MAX_EVENTS];
	while (1)
	{
		int num = epoll_wait(epfd, evs, MAX_EVENTS, -1);
		printf("num = %d\n", num);
		/*for(int e = 0; e<MAX_EVENTS; e++){
			         printf("%d",evs[e].data.fd);
		}*/
		for (int i = 0; i < num; i++)
		{
			if (evs[i].data.fd == socketfd)
			{
				socklen_t clientAddressLength = sizeof(clientAddress);
				// 接收请求
				int clientSocket = accept(socketfd, (struct sockaddr *)&clientAddress, &clientAddressLength);
				// 设置非阻塞属性
				int flag = fcntl(clientSocket, F_GETFL);
				fcntl(clientSocket, F_SETFL, flag);
				if (clientSocket == -1)
				{
					perror("accept");
				}
				ev.events = EPOLLIN | EPOLLET; // 设置边沿触发模式
				ev.data.fd = clientSocket;
				epoll_ctl(epfd, EPOLL_CTL_ADD, clientSocket, &ev);
			}
			else
			{
				struct clientMessage receivedMessage;
				struct serverMessage responseMessage;
				// 接收数据
				int ret = recv(evs[i].data.fd, &receivedMessage, sizeof(receivedMessage), 0);
				PRINT_LOG("Value of ret: %d", ret);
				if (ret == -1)
				{
					if (errno == EAGAIN)
					{
						printf("数据接收完毕\n");
						break;
					}
					else
					{
						perror("recv");
						exit(1);
					}
				}
				else if (ret == 0)
				{
					printf("客户端已经断开连接！\n");
					epoll_ctl(epfd, EPOLL_CTL_DEL, evs[i].data.fd, NULL);
					close(evs[i].data.fd);
					break;
				}
				else
				{
					// 消息验证
					if (receivedMessage.magic == MAGIC)
					{
						// 打印接收到的数据
						printf("Received Message:\n");
						printf("  Magic: 0x%X\n", receivedMessage.magic);
						printf("  Type: %d\n", receivedMessage.type);
						printf("  Message: %s\n", receivedMessage.msg);
					}
					// 构建响应数据
					responseMessage.magic = MAGIC;
					responseMessage.type = 2;
					responseMessage.timestamp = time(NULL);
					// 发送响应数据
					ret = send(evs[i].data.fd, &responseMessage, sizeof(responseMessage), 0);
					PRINT_LOG("Value of ret: %d", ret);
					if (ret == -1)
					{
						perror("send");
						exit(1);
					}
				}
			}
		}
	}
	close(socketfd);
	return 0;
}
