#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#define PORT 8080
#define IP "127.0.0.1"
#define MAGIC 0xDA12EEEE
#define MAX_SIZE 256
// 定义数据传输的结构体
struct clientMessage
{
    int magic;          // 魔数
    int type;           // 消息类型
    char msg[MAX_SIZE]; // 消息内容
};

struct serverMessage
{
    int magic;
    int type;
    long timestamp;
};

int main()
{
    int clientSocket;
    struct sockaddr_in serverAddress;

    // 创建 TCP Socket
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);

    // 配置 Server 地址信息
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = inet_addr(IP);
    serverAddress.sin_port = htons(PORT);

    // 连接 Server
    if (connect(clientSocket, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) == -1)
    {
        perror("Failed to connect");
        exit(1);
    }

    struct clientMessage sendMessage;
    struct serverMessage receivedMessage;
    int flag = 0;
    while (flag != 5)
    {
        // 构建数据
        sendMessage.magic = MAGIC;
        sendMessage.type = 0;
        strncpy(sendMessage.msg, "Client0", 255);

        // 发送数据
        int ret = send(clientSocket, &sendMessage, sizeof(sendMessage), 0);
        printf("send len=%d\n", ret);

        if ((recv(clientSocket, &receivedMessage, sizeof(receivedMessage), 0) == -1))
        {
            perror("Failed to receive");
            exit(1);
        }
        // 消息验证
        if (receivedMessage.magic == MAGIC)
        {
            // 打印接收到的响应数据
            printf("Received Response:\n");
            printf("  Magic: 0x%X\n", receivedMessage.magic);
            printf("  Type: %d\n", receivedMessage.type);
            printf("  Timestamp: %ld\n", receivedMessage.timestamp);
        }
        flag++;
        printf("flag:%d\n", flag);
        sleep(2);
    }
    // 关闭连接
    close(clientSocket);

    return 0;
}
